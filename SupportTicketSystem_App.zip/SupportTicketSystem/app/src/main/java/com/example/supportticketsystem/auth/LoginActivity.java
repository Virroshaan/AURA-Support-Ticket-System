package com.example.supportticketsystem.auth;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.supportticketsystem.R;
import com.example.supportticketsystem.technician.TechnicianDashboardActivity;
import com.example.supportticketsystem.user.TicketListActivity;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);

        FirebaseApp.initializeApp(this);
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        findViewById(R.id.btnLogin).setOnClickListener(v -> doLogin());
    }

    private void doLogin() {
        String email = etEmail.getText().toString().trim();
        String pass  = etPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        findViewById(R.id.btnLogin).setEnabled(false);

        auth.signInWithEmailAndPassword(email, pass)
                .addOnSuccessListener(result -> {
                    FirebaseUser user = result.getUser();
                    if (user == null) {
                        fail("Login failed.");
                        return;
                    }

                    user.reload().addOnCompleteListener(reloadTask -> {
                        FirebaseUser fresh = auth.getCurrentUser();
                        if (fresh == null) {
                            fail("Login failed.");
                            return;
                        }

                        if (!fresh.isEmailVerified()) {
                            Intent i = new Intent(this, VerifyEmailActivity.class);
                            i.putExtra("email", fresh.getEmail());
                            startActivity(i);
                            finish();
                            return;
                        }

                        fetchProfileAndRoute(fresh.getUid(), fresh.getEmail());
                    });
                })
                .addOnFailureListener(e -> fail(e.getMessage()));
    }

    private void fetchProfileAndRoute(String uid, @Nullable String email) {
        db.collection("users").document(uid).get()
                .addOnSuccessListener(snap -> {
                    if (snap.exists()) {
                        handleProfile(snap);
                    } else if (email != null) {
                        db.collection("users").whereEqualTo("email", email).limit(1).get()
                                .addOnSuccessListener(q -> {
                                    if (!q.isEmpty()) {
                                        DocumentSnapshot found = q.getDocuments().get(0);
                                        db.collection("users").document(uid).set(found.getData())
                                                .addOnSuccessListener(v -> handleProfile(found))
                                                .addOnFailureListener(e -> handleProfile(found));
                                    } else {
                                        fail("Your account is not activated yet. Please contact admin.");
                                    }
                                })
                                .addOnFailureListener(e -> fail("Failed to read profile: " + e.getMessage()));
                    } else {
                        fail("Profile not found. Contact admin.");
                    }
                })
                .addOnFailureListener(e -> fail("Failed to read profile: " + e.getMessage()));
    }

    private void handleProfile(DocumentSnapshot snap) {
        String role = getStringCaseInsensitive(snap, "role");
        if (role == null) role = "";

        Boolean active = snap.getBoolean("active");
        boolean isActive = (active == null) ? true : active;
        if (!isActive) {
            fail("Account disabled. Please contact admin.");
            return;
        }

        boolean mustChange = Boolean.TRUE.equals(snap.getBoolean("mustChangePassword"));
        if (mustChange) {
            startActivity(new Intent(this, ChangePasswordActivity.class));
            finish();
            return;
        }

        requestNotifPermissionIfNeeded();
        registerFcmToken();

        switch (role.toLowerCase()) {
            case "technician":
                startActivity(new Intent(this, TechnicianDashboardActivity.class));
                break;
            case "user":
                startActivity(new Intent(this, TicketListActivity.class));
                break;
            default:
                fail("Role not recognized. Contact admin.");
                return;
        }
        finish();
    }

    @Nullable
    private String getStringCaseInsensitive(DocumentSnapshot snap, String key) {
        if (snap.contains(key)) return snap.getString(key);
        if (key.equals("role")  && snap.contains("Role"))  return snap.getString("Role");
        if (key.equals("email") && snap.contains("Email")) return snap.getString("Email");
        if (key.equals("name")  && snap.contains("Name"))  return snap.getString("Name");
        return null;
    }

    private void fail(@Nullable String msg) {
        findViewById(R.id.btnLogin).setEnabled(true);
        Toast.makeText(this, msg == null ? "Login failed" : msg, Toast.LENGTH_LONG).show();
    }

    private void requestNotifPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9001);
        }
    }

    private void registerFcmToken() {
        com.google.firebase.messaging.FirebaseMessaging.getInstance().getToken()
                .addOnSuccessListener(token -> {
                    FirebaseUser cur = FirebaseAuth.getInstance().getCurrentUser();
                    if (cur == null) return;
                    String uid = cur.getUid();
                    FirebaseFirestore.getInstance()
                            .collection("users").document(uid)
                            .set(java.util.Collections.singletonMap("fcmToken", token),
                                    com.google.firebase.firestore.SetOptions.merge());
                });
    }

    // ✅ Universal logout helper
    public static void logoutAndGoToLogin(@NonNull Context ctx) {
        FirebaseAuth.getInstance().signOut();
        Intent i = new Intent(ctx, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        ctx.startActivity(i);
        if (ctx instanceof Activity) {
            ((Activity) ctx).finish();
        }
        Toast.makeText(ctx, "Logged out successfully", Toast.LENGTH_SHORT).show();
    }
}
