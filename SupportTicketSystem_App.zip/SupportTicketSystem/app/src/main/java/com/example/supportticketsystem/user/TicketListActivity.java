package com.example.supportticketsystem.user;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.supportticketsystem.R;
import com.example.supportticketsystem.adapter.TicketAdapter;
import com.example.supportticketsystem.auth.MainActivity;
import com.example.supportticketsystem.model.Ticket;
import com.example.supportticketsystem.model.TicketStore;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

public class TicketListActivity extends AppCompatActivity {

    private ListView listView;
    private EditText etSearch;
    private Button btnNewTicket;
    private ImageButton btnAddTicket;

    // Drawer views
    private DrawerLayout drawerLayout;
    private ImageButton btnMenuUser;
    private NavigationView navViewUser;

    private final List<Ticket> allTickets = new ArrayList<>();
    private final List<Ticket> visibleTickets = new ArrayList<>();
    private TicketAdapter adapter;

    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private String myUid = "";
    private ListenerRegistration reg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket_list);

        listView     = findViewById(R.id.listTickets);
        etSearch     = findViewById(R.id.etSearch);
        btnAddTicket = findViewById(R.id.btnAddTicket);

        // Drawer setup
        drawerLayout = findViewById(R.id.drawer_layout_user);
        btnMenuUser  = findViewById(R.id.btnMenuUser);
        navViewUser  = findViewById(R.id.nav_view_user);

        // Firebase
        db   = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        myUid = (auth.getCurrentUser() != null) ? auth.getCurrentUser().getUid() : "";

        // open drawer
        if (btnMenuUser != null && drawerLayout != null) {
            btnMenuUser.setOnClickListener(v ->
                    drawerLayout.openDrawer(GravityCompat.START));
        }

        // setup drawer header and menu items
        if (navViewUser != null && auth.getCurrentUser() != null) {
            View header = navViewUser.getHeaderView(0);
            TextView tvUserNameHeader = header.findViewById(R.id.tvUserNameHeader);
            TextView tvUserRoleHeader = header.findViewById(R.id.tvUserRoleHeader);

            // default label
            if (tvUserRoleHeader != null) tvUserRoleHeader.setText("AURA User");

            // load actual name from Firestore
            String uid = auth.getCurrentUser().getUid();
            db.collection("users").document(uid)
                    .get()
                    .addOnSuccessListener(doc -> {
                        if (doc.exists()) {
                            String name = doc.getString("name");
                            if (tvUserNameHeader != null) {
                                tvUserNameHeader.setText(
                                        name != null && !name.trim().isEmpty() ? name : "User"
                                );
                            }
                        } else {
                            if (tvUserNameHeader != null) tvUserNameHeader.setText("User");
                        }
                    })
                    .addOnFailureListener(e -> {
                        if (tvUserNameHeader != null) tvUserNameHeader.setText("User");
                    });

            // drawer navigation
            navViewUser.setNavigationItemSelectedListener(item -> {
                int id = item.getItemId();

                if (id == R.id.nav_profile) {
                    startActivity(new Intent(TicketListActivity.this, UserProfileActivity.class));
                } else if (id == R.id.nav_about) {
                    startActivity(new Intent(TicketListActivity.this, UserAboutActivity.class));
                } else if (id == R.id.nav_logout) {
                    MainActivity.logoutAndReturnToMain(TicketListActivity.this);
                }

                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            });
        }

        adapter = new TicketAdapter(this, new ArrayList<>(visibleTickets), myUid);
        listView.setAdapter(adapter);

        if (btnAddTicket != null) {
            btnAddTicket.setOnClickListener(v ->
                    startActivity(new Intent(TicketListActivity.this, NewTicketActivity.class)));
        }

        hookSearch();
    }

    @Override
    protected void onStart() {
        super.onStart();
        attachListener();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (reg != null) {
            reg.remove();
            reg = null;
        }
    }

    private void attachListener() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Not logged in", Toast.LENGTH_SHORT).show();
            return;
        }
        myUid = auth.getCurrentUser().getUid();

        if (reg != null) {
            reg.remove();
            reg = null;
        }

        reg = db.collection("tickets")
                .whereEqualTo("userId", myUid)
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Load failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    allTickets.clear();
                    if (snap != null) {
                        for (DocumentSnapshot d : snap.getDocuments()) {
                            Ticket t = TicketStore.fromDoc(d);
                            if (t != null) allTickets.add(t);
                        }
                    }
                    applyFilter(etSearch != null ? etSearch.getText().toString() : "");
                });
    }

    private void hookSearch() {
        if (etSearch == null) return;
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                applyFilter(s.toString());
            }
        });
    }

    private void applyFilter(String query) {
        String q = query == null ? "" : query.trim().toLowerCase();

        visibleTickets.clear();
        if (q.isEmpty()) {
            visibleTickets.addAll(allTickets);
        } else {
            for (Ticket t : allTickets) {
                String hay = ((t.subject == null ? "" : t.subject) + " " +
                        (t.category == null ? "" : t.category) + " " +
                        (t.description == null ? "" : t.description) + " " +
                        (t.code == null ? "" : t.code)).toLowerCase();
                if (hay.contains(q)) visibleTickets.add(t);
            }
        }

        adapter = new TicketAdapter(this, new ArrayList<>(visibleTickets), myUid);
        listView.setAdapter(adapter);
    }
}
