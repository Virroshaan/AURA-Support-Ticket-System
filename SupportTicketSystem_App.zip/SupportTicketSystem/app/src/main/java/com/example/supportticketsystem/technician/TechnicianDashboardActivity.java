package com.example.supportticketsystem.technician;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.supportticketsystem.DirectChatActivity;
import com.example.supportticketsystem.R;
import com.example.supportticketsystem.adapter.TicketAdapter;
import com.example.supportticketsystem.auth.LoginActivity;
import com.example.supportticketsystem.model.Ticket;
import com.example.supportticketsystem.model.TicketStore;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.Arrays;

public class TechnicianDashboardActivity extends AppCompatActivity {

    private ListView listView;
    private EditText etSearch;
    private ImageButton btnChat;      // bottom-right chat
    private ImageButton btnMenuTech;  // top-left menu

    private DrawerLayout drawerLayout;
    private NavigationView navView;

    private final ArrayList<Ticket> allTickets = new ArrayList<>();
    private final ArrayList<Ticket> visibleTickets = new ArrayList<>();
    private TicketAdapter adapter;

    private FirebaseFirestore db;
    private FirebaseAuth auth;

    private ListenerRegistration reg;
    private String myUid = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_technician_dashboard);

        listView     = findViewById(R.id.listTechTickets);
        etSearch     = findViewById(R.id.etSearchTech);
        btnChat      = findViewById(R.id.btnChat);
        btnMenuTech  = findViewById(R.id.btnMenuTech);
        drawerLayout = findViewById(R.id.drawerLayoutTech);
        navView      = findViewById(R.id.navViewTech);

        db   = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        myUid = (auth.getCurrentUser() != null) ? auth.getCurrentUser().getUid() : "";

        adapter = new TicketAdapter(this, visibleTickets, myUid);
        listView.setAdapter(adapter);

        // list item tap -> ticket details
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Ticket t = (Ticket) adapter.getItem(position);
            if (t == null || t.id == null || t.id.trim().isEmpty()) return;

            Intent i = new Intent(this, TicketDetailsTechnicianActivity.class);
            i.putExtra(TicketDetailsTechnicianActivity.EXTRA_TICKET_ID, t.id);
            startActivity(i);
        });

        // bottom-right chat button
        if (btnChat != null) {
            btnChat.setOnClickListener(v -> openAdminChat());
        }

        // menu (hamburger) button opens drawer
        if (btnMenuTech != null && drawerLayout != null) {
            btnMenuTech.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.START));
        }

        // drawer items + header binding from Firestore
        if (navView != null) {
            View header = navView.getHeaderView(0);
            TextView tvName = header.findViewById(R.id.tvTechName);
            TextView tvRole = header.findViewById(R.id.tvTechRole);

            if (auth.getCurrentUser() != null) {
                db.collection("users")
                        .document(auth.getCurrentUser().getUid())
                        .get()
                        .addOnSuccessListener(doc -> {
                            if (doc.exists()) {
                                String name = doc.getString("name");
                                if (name == null || name.trim().isEmpty()) {
                                    name = "Technician";
                                }
                                if (tvName != null) {
                                    tvName.setText(name);
                                }

                                // your Firestore has role: "technician"
                                String role = doc.getString("role");
                                if (tvRole != null) {
                                    if (role != null && role.equalsIgnoreCase("technician")) {
                                        tvRole.setText("AURA Technician");
                                    } else {
                                        tvRole.setText("AURA User");
                                    }
                                }
                            }
                        });
            }

            navView.setNavigationItemSelectedListener(item -> {
                int id = item.getItemId();
                if (id == R.id.nav_about) {
                    startActivity(new Intent(this, InfoActivity.class));
                } else if (id == R.id.nav_profile) {
                    startActivity(new Intent(this, TechnicianProfileActivity.class));
                } else if (id == R.id.nav_logout) {
                    doLogout();
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            });
        }

        // search filter
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                applyFilter(s == null ? "" : s.toString());
            }
        });
    }

    private void doLogout() {
        auth.signOut();
        Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, LoginActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        attachListener();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (reg != null) { reg.remove(); reg = null; }
    }

    @Override
    protected void onDestroy() {
        if (reg != null) { reg.remove(); reg = null; }
        super.onDestroy();
    }

    private void attachListener() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Technician not logged in", Toast.LENGTH_SHORT).show();
            return;
        }
        myUid = auth.getCurrentUser().getUid();

        if (reg != null) { reg.remove(); reg = null; }

        reg = db.collection("tickets")
                .whereEqualTo("assignedTo", myUid)
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Tickets error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        return;
                    }
                    allTickets.clear();
                    if (snap != null && !snap.isEmpty()) {
                        for (DocumentSnapshot d : snap.getDocuments()) {
                            Ticket t = TicketStore.fromDoc(d);
                            if (t != null) allTickets.add(t);
                        }
                    }
                    applyFilter(etSearch.getText() == null ? "" : etSearch.getText().toString());
                });
    }

    private void applyFilter(String raw) {
        String q = raw == null ? "" : raw.trim().toLowerCase();
        visibleTickets.clear();

        if (q.isEmpty()) {
            visibleTickets.addAll(allTickets);
        } else {
            for (Ticket t : allTickets) {
                String hay = ((t.subject == null ? "" : t.subject) + " " +
                        (t.description == null ? "" : t.description) + " " +
                        (t.category == null ? "" : t.category)).toLowerCase();
                if (hay.contains(q)) visibleTickets.add(t);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void openAdminChat() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            return;
        }
        db.collection("users")
                .whereIn("role", Arrays.asList("super_admin", "Super Admin"))
                .limit(1)
                .get()
                .addOnSuccessListener(q -> {
                    if (q.isEmpty()) {
                        Toast.makeText(this, "No super admin account found.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Intent i = new Intent(this, DirectChatActivity.class);
                    startActivity(i);
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to open admin chat: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }
}
