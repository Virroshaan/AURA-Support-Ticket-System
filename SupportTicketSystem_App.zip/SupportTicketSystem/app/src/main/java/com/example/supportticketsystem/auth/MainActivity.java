package com.example.supportticketsystem.auth;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.supportticketsystem.R;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_NOTIF = 2201;
    private LinearLayout btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin = findViewById(R.id.btnLogin);

        requestNotificationPermissionIfNeeded();

        // 🟢 handle logout intent
        if (getIntent().getBooleanExtra("logout", false)) {
            FirebaseAuth.getInstance().signOut();
            Toast.makeText(this, "You have been logged out.", Toast.LENGTH_SHORT).show();
        }

        if (btnLogin != null) {
            Animation fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
            btnLogin.startAnimation(fadeIn);
            btnLogin.setOnClickListener(v -> openLogin());
        } else {
            openLogin();
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQ_NOTIF
                );
            }
        }
    }

    public void openLogin() {
        startActivity(new Intent(MainActivity.this, LoginActivity.class));
    }

    public void onLoginClicked(View v) {
        openLogin();
    }

    // ✅ static helper: call this to perform logout from anywhere
    public static void logoutAndReturnToMain(AppCompatActivity activity) {
        FirebaseAuth.getInstance().signOut();
        Intent i = new Intent(activity, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        i.putExtra("logout", true);
        activity.startActivity(i);
        activity.finish();
    }
}
