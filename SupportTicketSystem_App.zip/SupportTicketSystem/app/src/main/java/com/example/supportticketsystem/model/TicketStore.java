package com.example.supportticketsystem.model;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TicketStore {
    private static final String PREF = "tickets_pref";
    private static final String KEY  = "tickets_json";

    public static List<Ticket> load(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY, "[]");
        List<Ticket> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                out.add(Ticket.fromJson(arr.getJSONObject(i)));
            }
        } catch (JSONException ignored) {}
        return out;
    }

    private static void save(Context ctx, List<Ticket> list) {
        JSONArray arr = new JSONArray();
        for (Ticket t : list) {
            try { arr.put(t.toJson()); } catch (JSONException ignored) {}
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY, arr.toString())
                .apply();
    }

    public static Ticket add(Context ctx, String category, String subject, String description, boolean urgent) {
        List<Ticket> list = load(ctx);

        Ticket t = new Ticket(
                UUID.randomUUID().toString(),
                (category == null || category.trim().isEmpty()) ? "General" : category.trim(),
                subject == null ? "" : subject.trim(),
                description == null ? "" : description.trim(),
                urgent,
                Timestamp.now()
        );
        t.status = "Open";

        list.add(0, t);
        save(ctx, list);
        return t;
    }

    @SuppressWarnings("unchecked")
    public static Ticket fromDoc(DocumentSnapshot d) {
        Ticket t = d.toObject(Ticket.class);
        if (t == null) t = new Ticket();

        t.id = d.getId();

        if (t.category == null)    t.category    = d.getString("category");
        if (t.subject == null)     t.subject     = d.getString("subject");
        if (t.description == null) t.description = d.getString("description");

        if (t.createdAt == null) {
            Timestamp ts = d.getTimestamp("createdAt");
            t.createdAt = (ts != null) ? ts : Timestamp.now();
        }

        String st = d.getString("status");
        t.status = (st == null || st.trim().isEmpty()) ? "Open" : st.trim();

        String rb = d.getString("resolvedBy");
        t.resolvedBy = (rb == null || rb.trim().isEmpty()) ? null : rb.trim();

        // ✅ map human-readable code from Firestore
        String ticketCode = d.getString("ticketCode");
        t.code = (ticketCode != null && !ticketCode.trim().isEmpty()) ? ticketCode.trim() : null;

        Object rm = d.get("reads");
        if (rm instanceof Map) {
            try {
                t.reads = (Map<String, Timestamp>) rm;
            } catch (Throwable ex) {
                t.reads = new HashMap<>();
            }
        } else {
            t.reads = new HashMap<>();
        }

        Object um = d.get("unread");
        if (um instanceof Map) {
            try {
                t.unread = (Map<String, Object>) um;
            } catch (Throwable ex) {
                t.unread = new HashMap<>();
            }
        } else {
            t.unread = new HashMap<>();
        }

        Object ad = d.get("autoDiagnostic");
        if (ad instanceof Map) {
            try {
                t.autoDiagnostic = (Map<String, Object>) ad;
            } catch (Throwable ex) {
                t.autoDiagnostic = new HashMap<>();
            }
        } else {
            t.autoDiagnostic = new HashMap<>();
        }

        return t;
    }
}
