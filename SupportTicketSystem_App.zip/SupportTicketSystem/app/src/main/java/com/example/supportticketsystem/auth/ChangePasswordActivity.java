package com.example.supportticketsystem.auth;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.supportticketsystem.R;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.functions.FirebaseFunctions;

public class ChangePasswordActivity extends AppCompatActivity {

    private EditText etNew, etConfirm;
    private Button btnSave, btnCancel;

    private FirebaseAuth auth;
    private FirebaseFunctions functions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        auth = FirebaseAuth.getInstance();
        functions = FirebaseFunctions.getInstance("asia-southeast1");

        etNew = findViewById(R.id.etNewPassword);
        etConfirm = findViewById(R.id.etConfirmPassword);
        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        btnSave.setOnClickListener(v -> doChange());
        btnCancel.setOnClickListener(v -> {
            // If they cancel, log out. You can change this if you like suffering.
            auth.signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void doChange() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        String p1 = etNew.getText().toString();
        String p2 = etConfirm.getText().toString();

        if (TextUtils.isEmpty(p1) || p1.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!p1.equals(p2)) {
            Toast.makeText(this, "Passwords do not match.", Toast.LENGTH_LONG).show();
            return;
        }

        btnSave.setEnabled(false);

        user.updatePassword(p1)
                .addOnSuccessListener(v -> {
                    // Clear the mustChangePassword flag server-side
                    functions
                            .getHttpsCallable("clearMustChangePassword")
                            .call()
                            .addOnSuccessListener(r -> {
                                Toast.makeText(this, "Password updated. Please log in again.", Toast.LENGTH_LONG).show();
                                auth.signOut();
                                startActivity(new Intent(this, LoginActivity.class));
                                finish();
                            })
                            .addOnFailureListener(e -> {
                                // Even if flag clear fails, don't trap the user here.
                                Toast.makeText(this, "Password updated, but flag not cleared: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                auth.signOut();
                                startActivity(new Intent(this, LoginActivity.class));
                                finish();
                            });
                })
                .addOnFailureListener(e -> {
                    btnSave.setEnabled(true);
                    Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }
}
