package com.example.supportticketsystem.technician;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.supportticketsystem.R;
import com.example.supportticketsystem.auth.LoginActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class InfoActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navView;
    private ImageView btnHomeTech; // changed to ImageView (no background box)

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        drawerLayout = findViewById(R.id.drawerLayoutTech);
        navView      = findViewById(R.id.navViewTech);
        btnHomeTech  = findViewById(R.id.btnHomeTech);

        auth = FirebaseAuth.getInstance();
        db   = FirebaseFirestore.getInstance();

        // Home button → go back to technician dashboard
        if (btnHomeTech != null) {
            btnHomeTech.setOnClickListener(v -> {
                Intent i = new Intent(this, TechnicianDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            });
        }

        // Set header name dynamically
        if (navView != null && auth.getCurrentUser() != null) {
            View header = navView.getHeaderView(0);
            TextView tvHeaderName = header.findViewById(R.id.tvTechName);

            String uid = auth.getCurrentUser().getUid();
            db.collection("users").document(uid)
                    .get()
                    .addOnSuccessListener(doc -> {
                        if (doc.exists()) {
                            String name = doc.getString("name");
                            if (name == null || name.trim().isEmpty()) name = "Technician";
                            tvHeaderName.setText(name);
                        }
                    });
        }

        // Drawer item actions
        if (navView != null) {
            navView.setNavigationItemSelectedListener(item -> {
                int id = item.getItemId();
                if (id == R.id.nav_about) {
                    // already here
                } else if (id == R.id.nav_profile) {
                    startActivity(new Intent(this, TechnicianProfileActivity.class));
                } else if (id == R.id.nav_logout) {
                    doLogout();
                }
                if (drawerLayout != null) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                return true;
            });
        }
    }

    private void doLogout() {
        auth.signOut();
        Intent i = new Intent(this, LoginActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
