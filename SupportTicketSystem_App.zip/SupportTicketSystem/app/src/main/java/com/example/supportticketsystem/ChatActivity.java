package com.example.supportticketsystem;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.supportticketsystem.adapter.MessageAdapter;
import com.example.supportticketsystem.model.Message;
import com.example.supportticketsystem.notifications.MyFirebaseMessagingService;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Ticket chat (user <-> technician).
 * Messages path: tickets/{ticketId}/messages
 */
public class ChatActivity extends AppCompatActivity {

    public static final String EXTRA_TICKET_ID = "ticketId";
    private static final String TAG = "ChatActivity";

    private String ticketId;
    private String uid;              // current logged-in uid
    private String otherUid = null;  // opposite participant

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private RecyclerView rv;
    private EditText et;
    private ImageButton btnSend;

    private final ArrayList<Message> data = new ArrayList<>();
    private MessageAdapter adapter;
    private ListenerRegistration reg;

    private boolean sending = false;
    private long lastSendAt = 0L;
    private String lastSendText = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        ticketId = getIntent().getStringExtra(EXTRA_TICKET_ID);
        if (TextUtils.isEmpty(ticketId)) {
            Toast.makeText(this, "Missing ticket id", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Checking session…", Toast.LENGTH_SHORT).show();
        }
        uid = (auth.getCurrentUser() != null) ? auth.getCurrentUser().getUid() : null;
        db  = FirebaseFirestore.getInstance();

        rv      = findViewById(R.id.rvMessages);
        et      = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);

        et.setImeOptions(EditorInfo.IME_ACTION_SEND);
        et.setSingleLine(true);

        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        rv.setLayoutManager(lm);

        adapter = new MessageAdapter(uid, data);
        rv.setAdapter(adapter);

        btnSend.setOnClickListener(v -> send());
        et.setOnEditorActionListener((tv, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send();
                return true;
            }
            return false;
        });

        // home button from XML header
        ImageView btnHome = findViewById(R.id.btnHomeTech);
        if (btnHome != null) {
            btnHome.setOnClickListener(v -> {
                Intent i = new Intent(this, com.example.supportticketsystem.technician.TechnicianDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            });
        }

        loadTicketMeta();
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (auth.getCurrentUser() == null) {
            startActivity(new Intent(this, com.example.supportticketsystem.auth.LoginActivity.class));
            finish();
            return;
        }
        uid = auth.getCurrentUser().getUid();

        MyFirebaseMessagingService.ACTIVE_ROOM_KEY = "ticket:" + ticketId;
        attachListener();
        markTicketRead();   // also resets unread.{myUid} = 0
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (isFinishing()) MyFirebaseMessagingService.ACTIVE_ROOM_KEY = "";
        detachListener();
    }

    private void loadTicketMeta() {
        db.collection("tickets").document(ticketId)
                .get()
                .addOnSuccessListener(snap -> {
                    if (!snap.exists()) return;
                    String userId = snap.getString("userId");
                    String techId = snap.getString("assignedTo");
                    if (uid != null && uid.equals(userId)) {
                        otherUid = techId;
                    } else if (uid != null && uid.equals(techId)) {
                        otherUid = userId;
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to load ticket meta", Toast.LENGTH_SHORT).show());
    }

    private void attachListener() {
        detachListener();

        reg = db.collection("tickets")
                .document(ticketId)
                .collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null) {
                        Log.e(TAG, "Chat listen error", e);
                        Toast.makeText(this, "Chat listen error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (snap == null || isFinishing() || isDestroyed()) return;

                    data.clear();
                    Set<String> seen = new HashSet<>();
                    for (DocumentSnapshot d : snap.getDocuments()) {
                        Message m = d.toObject(Message.class);
                        if (m == null) continue;
                        m.id = d.getId();
                        if (seen.add(m.id)) data.add(m);
                    }
                    adapter.notifyDataSetChanged();
                    if (!data.isEmpty()) rv.scrollToPosition(data.size() - 1);

                    // mark reads live
                    markTicketRead();
                });
    }

    private void detachListener() {
        if (reg != null) {
            reg.remove();
            reg = null;
        }
    }

    /** Mark as read + reset unread counter */
    private void markTicketRead() {
        if (auth.getCurrentUser() == null) return;
        String my = auth.getCurrentUser().getUid();

        Map<String, Object> patch = new HashMap<>();
        patch.put("reads." + my, FieldValue.serverTimestamp());
        patch.put("unread." + my, 0);

        db.collection("tickets").document(ticketId).set(patch, SetOptions.merge());
    }

    private void send() {
        String text = et.getText().toString().trim();
        if (text.isEmpty()) return;

        if (TextUtils.isEmpty(otherUid)) {
            Toast.makeText(this, "Loading chat participants...", Toast.LENGTH_SHORT).show();
            loadTicketMeta();
            return;
        }

        long now = SystemClock.elapsedRealtime();
        if (sending) return;
        if (text.equals(lastSendText) && (now - lastSendAt) < 1500) return;

        sending = true;
        btnSend.setEnabled(false);

        Map<String, Object> m = new HashMap<>();
        m.put("senderId", uid);
        m.put("receiverId", otherUid);
        m.put("text", text);
        m.put("createdAt", FieldValue.serverTimestamp());

        db.collection("tickets").document(ticketId)
                .collection("messages")
                .add(m)
                .addOnSuccessListener(ref -> {
                    lastSendText = text;
                    lastSendAt = SystemClock.elapsedRealtime();
                    et.setText("");
                    sending = false;
                    btnSend.setEnabled(true);

                    // Touch meta
                    Map<String, Object> meta = new HashMap<>();
                    meta.put("lastMessageAt", FieldValue.serverTimestamp());
                    meta.put("lastMessageText", text);
                    meta.put("lastMessageSenderId", uid);
                    meta.put("updatedAt", FieldValue.serverTimestamp());
                    db.collection("tickets").document(ticketId).set(meta, SetOptions.merge());
                })
                .addOnFailureListener(err -> {
                    sending = false;
                    btnSend.setEnabled(true);
                    Toast.makeText(this, "Send failed: " + err.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

}
