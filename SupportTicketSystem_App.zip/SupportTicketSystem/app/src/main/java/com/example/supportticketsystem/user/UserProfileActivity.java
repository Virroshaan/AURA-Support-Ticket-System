package com.example.supportticketsystem.user;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.supportticketsystem.R;
import com.example.supportticketsystem.auth.MainActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class UserProfileActivity extends AppCompatActivity {

    private TextView tvUserName, tvUserEmail, tvUserContact, tvUserDept;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private DrawerLayout drawerLayout;
    private NavigationView navView;
    private ImageView btnHomeUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // main views
        tvUserName    = findViewById(R.id.tvUserName);
        tvUserEmail   = findViewById(R.id.tvUserEmail);
        tvUserContact = findViewById(R.id.tvUserContact);
        tvUserDept    = findViewById(R.id.tvUserDept);

        drawerLayout = findViewById(R.id.drawerLayoutUser);
        navView      = findViewById(R.id.navViewUser);
        btnHomeUser  = findViewById(R.id.btnHomeUser);

        auth = FirebaseAuth.getInstance();
        db   = FirebaseFirestore.getInstance();

        // back/home
        if (btnHomeUser != null) {
            btnHomeUser.setOnClickListener(v -> {
                Intent i = new Intent(this, TicketListActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            });
        }

        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "No user", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String uid = auth.getCurrentUser().getUid();

        // drawer header (name + AURA User)
        if (navView != null) {
            View header = navView.getHeaderView(0);
            TextView tvHeaderName = header.findViewById(R.id.tvUserNameHeader);
            TextView tvHeaderRole = header.findViewById(R.id.tvUserRoleHeader);

            db.collection("users").document(uid)
                    .get()
                    .addOnSuccessListener(doc -> {
                        if (doc.exists()) {
                            String name = doc.getString("name");
                            name = isBlank(name) ? "User" : name;
                            if (tvHeaderName != null) tvHeaderName.setText(name);
                            if (tvHeaderRole != null) tvHeaderRole.setText("AURA User");
                        }
                    });
        }

        // drawer menu
        if (navView != null) {
            navView.setNavigationItemSelectedListener(item -> {
                int id = item.getItemId();
                if (id == R.id.nav_profile) {
                    // already here
                } else if (id == R.id.nav_about) {
                    startActivity(new Intent(this, UserAboutActivity.class));
                } else if (id == R.id.nav_logout) {
                    MainActivity.logoutAndReturnToMain(this);
                }
                if (drawerLayout != null) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                return true;
            });
        }

        // load profile
        db.collection("users").document(uid)
                .get()
                .addOnSuccessListener(doc -> {
                    if (!doc.exists()) return;

                    String name   = doc.getString("name");
                    String email  = doc.getString("email");

                    // contact: try every possible key
                    String contact = firstNonEmpty(
                            doc.getString("contactNumber"),
                            doc.getString("contact"),
                            doc.getString("phone"),
                            doc.getString("phoneNumber"),
                            doc.getString("mobile"),
                            doc.getString("tel")
                    );

                    // department: try variants
                    String dept = firstNonEmpty(
                            doc.getString("department"),
                            doc.getString("dept"),
                            doc.getString("departmentName")
                    );

                    tvUserName.setText(!isBlank(name) ? name : "-");
                    tvUserEmail.setText(!isBlank(email) ? email : "-");
                    tvUserContact.setText(!isBlank(contact) ? contact : "-");
                    tvUserDept.setText(!isBlank(dept) ? dept : "-");
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to load profile: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private String firstNonEmpty(String... values) {
        if (values == null) return null;
        for (String v : values) {
            if (!isBlank(v)) {
                return v;
            }
        }
        return null;
    }
}
