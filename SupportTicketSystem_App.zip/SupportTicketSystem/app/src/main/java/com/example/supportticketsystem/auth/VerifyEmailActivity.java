package com.example.supportticketsystem.auth;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.supportticketsystem.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class VerifyEmailActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private TextView tvInfo;
    private Button btnResend, btnIVerified, btnLogout;

    private static String prefKey(String uid) { return "auto_sent_verify_" + uid; }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_email);

        auth = FirebaseAuth.getInstance();

        tvInfo = findViewById(R.id.tvInfo);
        btnResend = findViewById(R.id.btnResend);
        btnIVerified = findViewById(R.id.btnIVerified);
        btnLogout = findViewById(R.id.btnLogout);

        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "Session expired. Please login again.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        tvInfo.setText("We sent a verification link to:\n" + (user.getEmail() == null ? "(your email)" : user.getEmail()));

        // Auto-send ONCE per user per install, right when this screen opens
        String key = prefKey(user.getUid());
        boolean alreadySent = getSharedPreferences("verify_prefs", Context.MODE_PRIVATE).getBoolean(key, false);
        if (!alreadySent) {
            sendEmail(user, true);
        }

        btnResend.setOnClickListener(v -> sendEmail(user, false));

        btnIVerified.setOnClickListener(v -> {
            // reload and check flag
            user.reload().addOnCompleteListener(t -> {
                FirebaseUser fresh = auth.getCurrentUser();
                if (fresh != null && fresh.isEmailVerified()) {
                    Toast.makeText(this, "Email verified. Please login again.", Toast.LENGTH_SHORT).show();
                    auth.signOut();
                    startActivity(new Intent(this, LoginActivity.class));
                    finish();
                } else {
                    Toast.makeText(this, "Still not verified. Check your inbox.", Toast.LENGTH_LONG).show();
                }
            });
        });

        btnLogout.setOnClickListener(v -> {
            auth.signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void sendEmail(FirebaseUser user, boolean markAuto) {
        btnResend.setEnabled(false);
        user.sendEmailVerification()
                .addOnSuccessListener(v -> {
                    if (markAuto) {
                        getSharedPreferences("verify_prefs", Context.MODE_PRIVATE)
                                .edit().putBoolean(prefKey(user.getUid()), true).apply();
                    }
                    Toast.makeText(this, "Verification email sent.", Toast.LENGTH_SHORT).show();
                    btnResend.setEnabled(true);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Could not send email: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    btnResend.setEnabled(true);
                });
    }
}
