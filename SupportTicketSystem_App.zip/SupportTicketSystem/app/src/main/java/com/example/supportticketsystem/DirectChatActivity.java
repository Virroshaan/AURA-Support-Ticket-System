package com.example.supportticketsystem;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.supportticketsystem.adapter.MessageAdapter;
import com.example.supportticketsystem.model.Message;
import com.example.supportticketsystem.notifications.MyFirebaseMessagingService;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Technician <-> Super Admin direct chat.
 * messages path: directChats/{roomId}/messages
 * roomId pattern: adminUid_techUid  (ADMIN FIRST)
 */
public class DirectChatActivity extends AppCompatActivity {

    public static final String EXTRA_ADMIN_UID = "extra_admin_uid";
    public static final String EXTRA_ROOM_ID   = "extra_room_id"; // used by FCM tap

    private String adminUid;   // super admin uid
    private String techUid;    // current technician uid
    private String roomId;     // adminUid_techUid

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private RecyclerView rv;
    private EditText et;
    private ImageButton btnSend;

    private final ArrayList<Message> data = new ArrayList<>();
    private MessageAdapter adapter;
    private ListenerRegistration reg;

    private boolean sending = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // use the admin-to-tech chat layout
        setContentView(R.layout.activity_chat_tech_admin);

        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        techUid = auth.getCurrentUser().getUid();
        db = FirebaseFirestore.getInstance();

        // Inputs from intent (may be empty)
        String passedRoomId = getIntent().getStringExtra(EXTRA_ROOM_ID);
        if (passedRoomId == null) passedRoomId = getIntent().getStringExtra("roomId");
        adminUid = getIntent().getStringExtra(EXTRA_ADMIN_UID);

        // If we got a roomId, try to infer admin from participants
        if (!TextUtils.isEmpty(passedRoomId)) {
            roomId = passedRoomId;
            if (TextUtils.isEmpty(adminUid) && roomId.contains("_")) {
                String[] parts = roomId.split("_", 2);
                if (parts.length == 2) adminUid = parts[0];
            }
        }

        rv = findViewById(R.id.rvMessages);
        et = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);

        et.setImeOptions(EditorInfo.IME_ACTION_SEND);
        et.setSingleLine(true);

        LinearLayoutManager lm = new LinearLayoutManager(this);
        lm.setStackFromEnd(true);
        rv.setLayoutManager(lm);

        adapter = new MessageAdapter(techUid, data);
        rv.setAdapter(adapter);

        btnSend.setOnClickListener(v -> send());
        et.setOnEditorActionListener((tv, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send();
                return true;
            }
            return false;
        });

        // home button in this chat layout
        ImageView btnHome = findViewById(R.id.btnHomeTech);
        if (btnHome != null) {
            btnHome.setOnClickListener(v -> {
                Intent i = new Intent(this, com.example.supportticketsystem.technician.TechnicianDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            });
        }

        // If we still don't know admin/room, fall back to meta/app
        if (TextUtils.isEmpty(adminUid) || TextUtils.isEmpty(roomId)) {
            fetchAdminFromMetaAndInit();
        } else {
            ensureRoomDocument();
            recoverAdminIfMissing(); // in case only roomId came in
            // listener + reads will be attached in onStart
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (TextUtils.isEmpty(roomId)) return; // wait until resolved
        MyFirebaseMessagingService.ACTIVE_ROOM_KEY = "direct:" + roomId;
        attachListener();
        markDirectRead(); // mark read when visible
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (isFinishing()) MyFirebaseMessagingService.ACTIVE_ROOM_KEY = "";
        detachListener();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MyFirebaseMessagingService.ACTIVE_ROOM_KEY = "";
    }

    /** Read meta/app to pick primary admin, then complete setup. */
    private void fetchAdminFromMetaAndInit() {
        db.collection("meta").document("app").get()
                .addOnSuccessListener(s -> {
                    String primary = s.getString("primarySuperAdminUid");
                    if (TextUtils.isEmpty(primary)) {
                        // try first from otherSuperAdmins as last resort
                        List<String> others = (List<String>) s.get("otherSuperAdmins");
                        if (others != null && !others.isEmpty()) primary = others.get(0);
                    }
                    if (TextUtils.isEmpty(primary)) {
                        Toast.makeText(this, "Missing chat target (no admin configured).", Toast.LENGTH_SHORT).show();
                        finish();
                        return;
                    }
                    adminUid = primary;
                    roomId = adminUid + "_" + techUid; // ADMIN FIRST
                    ensureRoomDocument();
                    // now we can attach listener
                    MyFirebaseMessagingService.ACTIVE_ROOM_KEY = "direct:" + roomId;
                    attachListener();
                    markDirectRead();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to resolve admin: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    /** Create/merge the room doc (with participants) if known. */
    private void ensureRoomDocument() {
        Map<String, Object> roomInfo = new HashMap<>();
        roomInfo.put("updatedAt", FieldValue.serverTimestamp());
        if (!TextUtils.isEmpty(adminUid)) {
            roomInfo.put("participants", java.util.Arrays.asList(adminUid, techUid));
        }
        db.collection("directChats").document(roomId)
                .set(roomInfo, SetOptions.merge());
    }

    /** If we only know roomId, read participants and set adminUid for consistency. */
    private void recoverAdminIfMissing() {
        if (!TextUtils.isEmpty(adminUid)) return;
        db.collection("directChats").document(roomId).get()
                .addOnSuccessListener(s -> {
                    if (!s.exists()) return;
                    List<String> p = (List<String>) s.get("participants");
                    if (p != null && p.size() == 2) {
                        for (String x : p) {
                            if (!techUid.equals(x)) { adminUid = x; break; }
                        }
                    }
                });
    }

    private void attachListener() {
        detachListener();
        reg = db.collection("directChats").document(roomId)
                .collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .addSnapshotListener((snap, e) -> {
                    if (e != null) {
                        Toast.makeText(this, "Direct chat listen error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (snap == null) return;

                    HashMap<String, Message> map = new HashMap<>();
                    for (DocumentSnapshot d : snap.getDocuments()) {
                        Message m = d.toObject(Message.class);
                        if (m == null) continue;
                        m.id = d.getId();
                        if (m.createdAt == null) m.createdAt = Timestamp.now();
                        map.put(m.id, m);
                    }
                    data.clear();
                    data.addAll(map.values());
                    Collections.sort(data, (a, b) -> a.createdAt.compareTo(b.createdAt));
                    adapter.notifyDataSetChanged();
                    if (!data.isEmpty()) rv.scrollToPosition(data.size() - 1);

                    // mark read on refresh
                    markDirectRead();
                });
    }

    private void detachListener() {
        if (reg != null) { reg.remove(); reg = null; }
    }

    /** Write reads.{uid} on the room for current tech */
    private void markDirectRead() {
        if (auth.getCurrentUser() == null || TextUtils.isEmpty(roomId)) return;
        String my = auth.getCurrentUser().getUid();
        Map<String, Object> patch = new HashMap<>();
        patch.put("reads." + my, FieldValue.serverTimestamp());
        db.collection("directChats").document(roomId)
                .set(patch, SetOptions.merge());
    }

    private void send() {
        if (sending || TextUtils.isEmpty(roomId)) return;
        String text = et.getText().toString().trim();
        if (text.isEmpty()) return;

        sending = true;
        btnSend.setEnabled(false);

        Map<String, Object> m = new HashMap<>();
        m.put("senderId", techUid);
        m.put("text", text);
        m.put("createdAt", FieldValue.serverTimestamp());

        db.collection("directChats").document(roomId)
                .set(java.util.Collections.singletonMap("updatedAt", FieldValue.serverTimestamp()),
                        SetOptions.merge());

        db.collection("directChats").document(roomId)
                .collection("messages")
                .add(m)
                .addOnSuccessListener(ref -> {
                    et.setText("");
                    rv.scrollToPosition(Math.max(0, data.size() - 1));
                    sending = false;
                    btnSend.setEnabled(true);
                })
                .addOnFailureListener(err -> {
                    Toast.makeText(this, "Send failed: " + err.getMessage(), Toast.LENGTH_SHORT).show();
                    sending = false;
                    btnSend.setEnabled(true);
                });
    }
}
