package com.example.supportticketsystem.model;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class UserStore {
    private static final String PREF = "user_store_pref";
    private static final String KEY  = "users_json";

    private static JSONArray loadArray(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY, "[]");
        try { return new JSONArray(raw); }
        catch (JSONException e) { return new JSONArray(); }
    }

    private static void saveArray(Context ctx, JSONArray arr) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().putString(KEY, arr.toString()).apply();
    }

    public static boolean emailExists(Context ctx, String email) {
        JSONArray arr = loadArray(ctx);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject u = arr.optJSONObject(i);
            if (u != null && email.equalsIgnoreCase(u.optString("email"))) return true;
        }
        return false;
    }

    public static void addUser(Context ctx, String name, String email, String password) {
        JSONArray arr = loadArray(ctx);
        JSONObject u = new JSONObject();
        try {
            u.put("name", name);
            u.put("email", email);
            u.put("password", password); // demo only, don’t store plain text in real life
            arr.put(0, u);
            saveArray(ctx, arr);
        } catch (JSONException ignored) {}
    }
}
