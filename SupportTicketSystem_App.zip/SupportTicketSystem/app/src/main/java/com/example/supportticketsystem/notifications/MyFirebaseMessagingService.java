package com.example.supportticketsystem.notifications;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.RemoteInput;

import com.example.supportticketsystem.ChatActivity;
import com.example.supportticketsystem.DirectChatActivity;
import com.example.supportticketsystem.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.HashMap;
import java.util.Map;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    public static String ACTIVE_ROOM_KEY = ""; // "ticket:{id}" or "direct:{roomId}"

    private static final String CH_TICKET = "ticket_chat_notifications";
    private static final String CH_DIRECT = "direct_chat_notifications";
    private static final String KEY_INLINE = ReplyReceiver.KEY_INLINE;

    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            Map<String,Object> m = new HashMap<>();
            m.put("fcmToken", token);
            FirebaseFirestore.getInstance()
                    .collection("users").document(uid)
                    .set(m, com.google.firebase.firestore.SetOptions.merge());
        }
    }

    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        super.onMessageReceived(message);

        Map<String, String> data = message.getData() == null ? new HashMap<>() : message.getData();
        String type = data.get("type"); // ticketChat / directChat

        // Suppress notification if that conversation is open
        if ("directChat".equals(type)) {
            String roomId = data.get("roomId");
            if (("direct:" + roomId).equals(ACTIVE_ROOM_KEY)) return;
        } else {
            String ticketId = data.get("ticketId");
            if (("ticket:" + ticketId).equals(ACTIVE_ROOM_KEY)) return;
        }

        PendingIntent contentPI;
        PendingIntent replyPI;
        String channelId;
        String groupKey;
        int notifyId;

        if ("directChat".equals(type)) {
            String roomId = data.get("roomId");
            contentPI = buildDirectActivityPI(this, data);
            replyPI   = buildReplyReceiverPI(this, "directChat", null, roomId, data.get("adminUid"));
            channelId = CH_DIRECT;
            groupKey  = "grp_direct_" + (roomId == null ? "x" : roomId);
            notifyId  = (roomId == null) ? 991 : roomId.hashCode();
        } else {
            String ticketId = data.get("ticketId");
            contentPI = buildTicketActivityPI(this, data);
            replyPI   = buildReplyReceiverPI(this, "ticketChat", ticketId, null, null);
            channelId = CH_TICKET;
            groupKey  = "grp_ticket_" + (ticketId == null ? "x" : ticketId);
            notifyId  = (ticketId == null) ? 992 : ticketId.hashCode();
        }

        String title = firstNonEmpty(
                message.getNotification() != null ? message.getNotification().getTitle() : null,
                data.get("subject"), data.get("title"), "New message");
        String body  = firstNonEmpty(
                message.getNotification() != null ? message.getNotification().getBody()  : null,
                data.get("senderName") != null ? data.get("senderName") + ": " + data.get("text") : data.get("text"),
                "You have a new chat");

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        createChannels(nm);

        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder nb = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_support)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher))
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setSound(sound)
                .setVibrate(new long[]{0, 350, 250, 350})
                .setContentIntent(contentPI)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setGroup(groupKey);

        // Inline reply action -> Broadcast to ReplyReceiver
        RemoteInput ri = new RemoteInput.Builder(KEY_INLINE).setLabel("Reply").build();
        NotificationCompat.Action action =
                new NotificationCompat.Action.Builder(android.R.drawable.ic_menu_send, "Reply", replyPI)
                        .addRemoteInput(ri)
                        .setAllowGeneratedReplies(true)
                        .build();
        nb.addAction(action);

        nm.notify(notifyId, nb.build());
    }

    private static String firstNonEmpty(String... opts) {
        for (String s : opts) if (s != null && !s.trim().isEmpty()) return s;
        return "";
    }

    private void createChannels(NotificationManager nm) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        Uri sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        NotificationChannel ch1 = new NotificationChannel(
                CH_TICKET, "Ticket chat", NotificationManager.IMPORTANCE_HIGH);
        ch1.enableLights(true);
        ch1.setLightColor(Color.CYAN);
        ch1.enableVibration(true);
        ch1.setVibrationPattern(new long[]{0,350,250,350});
        ch1.setSound(sound, aa);

        NotificationChannel ch2 = new NotificationChannel(
                CH_DIRECT, "Direct chat (Admin)", NotificationManager.IMPORTANCE_HIGH);
        ch2.enableLights(true);
        ch2.setLightColor(Color.MAGENTA);
        ch2.enableVibration(true);
        ch2.setVibrationPattern(new long[]{0,350,250,350});
        ch2.setSound(sound, aa);

        nm.createNotificationChannel(ch1);
        nm.createNotificationChannel(ch2);
    }

    /** Opens ticket chat Activity when tapping the notification body */
    private PendingIntent buildTicketActivityPI(Context ctx, Map<String,String> data) {
        Intent i = new Intent(ctx, ChatActivity.class);
        i.putExtra(ChatActivity.EXTRA_TICKET_ID, data.get("ticketId"));
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
        return PendingIntent.getActivity(ctx, (int) System.currentTimeMillis(), i, flags);
    }

    /** Opens direct chat Activity when tapping the notification body */
    private PendingIntent buildDirectActivityPI(Context ctx, Map<String,String> data) {
        Intent i = new Intent(ctx, DirectChatActivity.class);
        //i.putExtra(DirectChatActivity.EXTRA_ROOM_ID, data.get("roomId"));
        //i.putExtra(DirectChatActivity.EXTRA_ADMIN_UID, data.get("adminUid"));
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
        return PendingIntent.getActivity(ctx, (int) System.currentTimeMillis(), i, flags);
    }

    /** PendingIntent for the BroadcastReceiver that will send an inline reply without opening UI */
    private PendingIntent buildReplyReceiverPI(Context ctx, String type, String ticketId, String roomId, String adminUid) {
        Intent i = new Intent(ctx, ReplyReceiver.class);
        i.putExtra("type", type);
        if (ticketId != null) i.putExtra("ticketId", ticketId);
        if (roomId   != null) i.putExtra("roomId", roomId);
        if (adminUid != null) i.putExtra("adminUid", adminUid);

        // IMPORTANT: RemoteInput requires MUTABLE pending intent on Android 12+
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE
                : (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_UPDATE_CURRENT /* mutable by default pre-S */
                : PendingIntent.FLAG_UPDATE_CURRENT);

        return PendingIntent.getBroadcast(ctx, (int) System.currentTimeMillis(), i, flags);
    }
}
