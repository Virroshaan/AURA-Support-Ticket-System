package com.example.supportticketsystem.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.supportticketsystem.ChatActivity;
import com.example.supportticketsystem.R;
import com.example.supportticketsystem.UserChatActivity;
import com.example.supportticketsystem.model.Ticket;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Source;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class TicketAdapter extends BaseAdapter {

    private final Context context;
    private final ArrayList<Ticket> tickets;
    private final String myUid;
    private final LayoutInflater inflater;
    private final SimpleDateFormat sdf =
            new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());

    private final FirebaseFirestore db = FirebaseFirestore.getInstance();

    // cache role so we don’t keep hitting Firestore
    private String myRole = null;

    public TicketAdapter(Context context, ArrayList<Ticket> tickets, String myUid) {
        this.context = context;
        this.tickets = tickets;
        this.myUid = myUid;
        this.inflater = LayoutInflater.from(context);
        fetchMyRole();
    }

    private void fetchMyRole() {
        if (myUid == null || myUid.trim().isEmpty()) {
            myRole = "user";
            return;
        }
        db.collection("users").document(myUid)
                .get()
                .addOnSuccessListener(snap -> {
                    String r = snap.getString("role");
                    myRole = (r == null) ? "user" : r.toLowerCase(Locale.getDefault());
                })
                .addOnFailureListener(e -> myRole = "user");
    }

    @Override public int getCount() { return tickets.size(); }
    @Override public Object getItem(int position) { return tickets.get(position); }
    @Override public long getItemId(int position) { return position; }

    static class VH {
        TextView tvSubject, tvMeta, tvDesc, tvStatusChip;
        Button btnChat;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        VH h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.row_ticket, parent, false);
            h = new VH();
            h.tvSubject    = convertView.findViewById(R.id.tvSubject);
            h.tvMeta       = convertView.findViewById(R.id.tvMeta);
            h.tvDesc       = convertView.findViewById(R.id.tvDescription);
            h.tvStatusChip = convertView.findViewById(R.id.tvStatusChip);
            h.btnChat      = convertView.findViewById(R.id.btnChat);
            convertView.setTag(h);
        } else {
            h = (VH) convertView.getTag();
        }

        final Ticket t = tickets.get(position);

        // Subject
        String code = t.code != null ? t.code : (t.id == null ? "" : t.id);
        String subjectLine = (t.urgent ? "⚠ " : "") +
                (t.subject != null && !t.subject.isEmpty() ? t.subject : "(No subject)");
        if (!code.isEmpty()) subjectLine += "  •  " + code;
        h.tvSubject.setText(subjectLine);

        String date = (t.createdAt != null) ? sdf.format(t.createdAt.toDate()) : "";
        String cat = (t.category != null && !t.category.isEmpty()) ? t.category : "General";
        h.tvMeta.setText(cat + (date.isEmpty() ? "" : " • " + date));

        h.tvDesc.setText(t.description != null ? t.description : "");

        // status chip
        String status = (t.status == null || t.status.trim().isEmpty()) ? "Open" : t.status.trim();
        styleStatusChip(h.tvStatusChip, status);

        // default chat label
        h.btnChat.setText("CHAT");

        // 1. try unread from the ticket object first
        int unread = 0;
        if (t.unread != null && myUid != null) {
            Object v = t.unread.get(myUid);
            if (v instanceof Number) unread = ((Number) v).intValue();
        }
        if (unread > 0) {
            h.btnChat.setText("CHAT (" + unread + "+)");
        } else if (t.id != null && !t.id.trim().isEmpty()) {
            // 2. if model didn't have it, pull latest from Firestore
            final Button btnRef = h.btnChat;
            db.collection("tickets").document(t.id)
                    .get(Source.SERVER)
                    .addOnSuccessListener(snap -> applyUnreadFromDoc(snap, btnRef));
        }

        // OPEN CORRECT CHAT
        h.btnChat.setOnClickListener(v -> {
            if (t.id == null || t.id.trim().isEmpty()) return;

            // optimistic: clear badge immediately in UI
            h.btnChat.setText("CHAT");

            // also update Firestore unread + reads for this user
            if (myUid != null) {
                Map<String, Object> updates = new HashMap<>();
                // unread.<uid> = 0
                updates.put("unread." + myUid, 0);
                // reads.<uid> = server time
                updates.put("reads." + myUid, FieldValue.serverTimestamp());
                db.collection("tickets").document(t.id).update(updates);
            }

            String role = (myRole == null) ? "user" : myRole;
            if ("technician".equals(role)) {
                Intent i = new Intent(context, ChatActivity.class);
                i.putExtra(ChatActivity.EXTRA_TICKET_ID, t.id);
                context.startActivity(i);
            } else {
                Intent i = new Intent(context, UserChatActivity.class);
                i.putExtra(UserChatActivity.EXTRA_TICKET_ID, t.id);
                context.startActivity(i);
            }
        });

        return convertView;
    }

    private void applyUnreadFromDoc(@NonNull DocumentSnapshot d, @NonNull Button btn) {
        if (!d.exists()) {
            btn.setText("CHAT");
            return;
        }

        int unread = 0;
        Object unreadMap = d.get("unread");
        if (unreadMap instanceof Map && myUid != null) {
            Object v = ((Map<?, ?>) unreadMap).get(myUid);
            if (v instanceof Number) unread = ((Number) v).intValue();
        }

        if (unread > 0) {
            btn.setText("CHAT (" + unread + "+)");
            return;
        }

        // fallback: infer from lastMessageAt vs reads
        Timestamp lastMessageAt = d.getTimestamp("lastMessageAt");
        String lastSender = d.getString("lastMessageSenderId");

        Timestamp lastRead = null;
        Object rm = d.get("reads");
        if (rm instanceof Map && myUid != null) {
            Object lr = ((Map<?, ?>) rm).get(myUid);
            if (lr instanceof Timestamp) lastRead = (Timestamp) lr;
        }

        boolean otherSent = (lastSender != null && !lastSender.equals(myUid));
        boolean newerThanRead = lastMessageAt != null && (lastRead == null || lastMessageAt.compareTo(lastRead) > 0);

        btn.setText(otherSent && newerThanRead ? "CHAT (1+)" : "CHAT");
    }

    private void styleStatusChip(@NonNull TextView chip, @NonNull String statusRaw) {
        String status = statusRaw.trim();
        chip.setText(status.toUpperCase(Locale.getDefault()));
        chip.setTextColor(Color.WHITE);

        int color = colorForStatus(status);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(12));
        chip.setBackground(bg);
    }

    private int colorForStatus(String status) {
        String s = status == null ? "" : status.trim().toLowerCase(Locale.getDefault());
        switch (s) {
            case "in progress":
            case "processing": return Color.parseColor("#1E88E5");
            case "pending":    return Color.parseColor("#FB8C00");
            case "resolved":
            case "done":       return Color.parseColor("#2E7D32");
            case "closed":
            case "cancelled":  return Color.parseColor("#607D8B");
            case "open":
            default:           return Color.parseColor("#9E9E9E");
        }
    }

    private float dp(float v) {
        return TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, context.getResources().getDisplayMetrics());
    }
}
