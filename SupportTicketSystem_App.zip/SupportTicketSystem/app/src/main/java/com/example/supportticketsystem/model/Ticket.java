package com.example.supportticketsystem.model;

import com.google.firebase.Timestamp;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Ticket {
    public String id;
    public String category;
    public String subject;
    public String code;          // <-- human ticket code like TKT-100123
    public String description;
    public boolean urgent;
    public Timestamp createdAt;

    public String status = "Open";

    public String resolvedBy;
    public Map<String, Object> autoDiagnostic = new HashMap<>();

    public Map<String, Timestamp> reads = new HashMap<>();
    public Map<String, Object> unread = new HashMap<>();

    public Ticket() {}

    public Ticket(String id, String category, String subject, String description,
                  boolean urgent, Timestamp createdAt) {
        this.id = id;
        this.category = category;
        this.subject = subject;
        this.description = description;
        this.urgent = urgent;
        this.createdAt = createdAt;
        this.status = "Open";
    }

    public Ticket(String subject, String category, String description) {
        this.id = null;
        this.subject = subject;
        this.category = category;
        this.description = description;
        this.urgent = false;
        this.createdAt = Timestamp.now();
        this.status = "Open";
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("category", category);
        o.put("subject", subject);
        o.put("description", description);
        o.put("urgent", urgent);
        o.put("status", status == null ? "Open" : status);
        o.put("resolvedBy", resolvedBy == null ? JSONObject.NULL : resolvedBy);
        o.put("code", code == null ? JSONObject.NULL : code); // persist code locally
        o.put("createdAt", createdAt != null ? createdAt.toDate().getTime() : System.currentTimeMillis());
        return o;
    }

    public static Ticket fromJson(JSONObject o) throws JSONException {
        long millis = o.optLong("createdAt", System.currentTimeMillis());
        Timestamp ts = new Timestamp(new java.util.Date(millis));
        Ticket t = new Ticket(
                o.optString("id", null),
                o.optString("category", "General"),
                o.optString("subject", ""),
                o.optString("description", ""),
                o.optBoolean("urgent", false),
                ts
        );
        t.status = o.optString("status", "Open");
        t.resolvedBy = o.optString("resolvedBy", null);
        t.code = o.optString("code", null);
        t.reads = new HashMap<>();
        t.unread = new HashMap<>();
        t.autoDiagnostic = new HashMap<>();
        return t;
    }

    public long getCreatedAtMillis() {
        return (createdAt != null) ? createdAt.toDate().getTime() : System.currentTimeMillis();
    }
}
