package com.example.supportticketsystem.user;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.supportticketsystem.R;
import com.example.supportticketsystem.auth.MainActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class UserAboutActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navView;
    private ImageView btnHomeUser;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_about);

        drawerLayout = findViewById(R.id.drawerLayoutUser);
        navView      = findViewById(R.id.navViewUser);
        btnHomeUser  = findViewById(R.id.btnHomeUser);

        auth = FirebaseAuth.getInstance();
        db   = FirebaseFirestore.getInstance();

        // home icon → back to ticket list
        if (btnHomeUser != null) {
            btnHomeUser.setOnClickListener(v -> {
                Intent i = new Intent(this, TicketListActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            });
        }

        // set header name + fixed "AURA User" role
        if (navView != null && auth.getCurrentUser() != null) {
            View header = navView.getHeaderView(0);
            TextView tvHeaderName = header.findViewById(R.id.tvUserNameHeader);
            TextView tvHeaderRole = header.findViewById(R.id.tvUserRoleHeader);

            if (tvHeaderRole != null) {
                tvHeaderRole.setText("AURA User");
            }

            String uid = auth.getCurrentUser().getUid();
            db.collection("users").document(uid)
                    .get()
                    .addOnSuccessListener(doc -> {
                        if (doc.exists()) {
                            String name = doc.getString("name");
                            if (name == null || name.trim().isEmpty()) {
                                name = "User";
                            }
                            if (tvHeaderName != null) {
                                tvHeaderName.setText(name);
                            }
                        }
                    });
        }

        // drawer item actions
        if (navView != null) {
            navView.setNavigationItemSelectedListener(item -> {
                int id = item.getItemId();

                if (id == R.id.nav_profile) {
                    startActivity(new Intent(this, UserProfileActivity.class));
                } else if (id == R.id.nav_about) {
                    // already here
                } else if (id == R.id.nav_logout) {
                    MainActivity.logoutAndReturnToMain(this);
                }

                if (drawerLayout != null) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                return true;
            });
        }
    }
}
