package com.example.supportticketsystem.adapter;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.supportticketsystem.R;
import com.example.supportticketsystem.model.Message;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.VH> {

    private final String myUid;
    private final ArrayList<Message> data;
    private final SimpleDateFormat timeFmt =
            new SimpleDateFormat("HH:mm", Locale.getDefault());

    public MessageAdapter(String myUid, ArrayList<Message> data) {
        this.myUid = myUid;
        this.data = data;
    }

    static class VH extends RecyclerView.ViewHolder {
        LinearLayout bubble;
        TextView tvText, tvTime;

        VH(@NonNull View v) {
            super(v);
            bubble = v.findViewById(R.id.bubble);
            tvText = v.findViewById(R.id.tvText);
            tvTime = v.findViewById(R.id.tvTime);
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_message_bubble, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Message m = (position >= 0 && position < data.size()) ? data.get(position) : null;
        boolean mine = (m != null && m.senderId != null && m.senderId.equals(myUid));

        h.tvText.setText((m == null || m.text == null) ? "" : m.text);

        String t = "";
        try {
            if (m != null && m.createdAt != null && m.createdAt.toDate() != null) {
                t = timeFmt.format(m.createdAt.toDate());
            }
        } catch (Throwable ignore) {}
        h.tvTime.setText(t);

        LinearLayout.LayoutParams lp =
                (LinearLayout.LayoutParams) h.bubble.getLayoutParams();
        if (mine) {
            lp.gravity = Gravity.END;
            h.bubble.setBackgroundResource(R.drawable.bg_bubble_me);
        } else {
            lp.gravity = Gravity.START;
            h.bubble.setBackgroundResource(R.drawable.bg_bubble_them);
        }
        h.bubble.setLayoutParams(lp);
    }

    @Override
    public int getItemCount() {
        return data == null ? 0 : data.size();
    }
}
