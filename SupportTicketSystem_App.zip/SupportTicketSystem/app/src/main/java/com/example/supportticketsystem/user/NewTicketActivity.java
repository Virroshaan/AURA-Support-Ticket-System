package com.example.supportticketsystem.user;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.supportticketsystem.R;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class NewTicketActivity extends AppCompatActivity {

    private Spinner spCategory;
    private EditText etSubject, etDescription;
    private Button btnAttach, btnSubmit;
    private ImageView ivPreview;

    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private FirebaseStorage storage;

    private Uri pickedImage;

    private final ActivityResultLauncher<String> pickMediaLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    pickedImage = uri;
                    ivPreview.setImageURI(uri);
                }
            });

    private final List<Map<String, Object>> diagRules = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_ticket);

        spCategory    = findViewById(R.id.spCategory);
        etSubject     = findViewById(R.id.etSubject);
        etDescription = findViewById(R.id.etDescription);
        btnAttach     = findViewById(R.id.btnAttachPhoto);
        btnSubmit     = findViewById(R.id.btnSubmit);
        ivPreview     = findViewById(R.id.ivPreview);

        // home button
        ImageView btnHomeUser = findViewById(R.id.btnHomeUser);
        if (btnHomeUser != null) {
            btnHomeUser.setOnClickListener(v -> {
                Intent i = new Intent(this, TicketListActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            });
        }

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        storage = FirebaseStorage.getInstance();

        if (spCategory.getAdapter() == null) {
            spCategory.setAdapter(new ArrayAdapter<>(
                    this, android.R.layout.simple_spinner_dropdown_item,
                    new String[]{"General", "Hardware", "Software", "Network", "Account"}));
        }

        btnAttach.setOnClickListener(v -> pickImage());
        btnSubmit.setOnClickListener(v -> trySubmitWithDiagnose());

        loadDiagRules();
    }

    private void pickImage() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, 1001);
                return;
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1002);
                return;
            }
        }
        pickMediaLauncher.launch("image/*");
    }

    private void loadDiagRules() {
        db.collection("diagnostics")
                .whereEqualTo("active", true)
                .get()
                .addOnSuccessListener(snap -> {
                    diagRules.clear();
                    for (QueryDocumentSnapshot d : snap) {
                        Map<String, Object> m = d.getData();
                        if (m != null) {
                            m.put("id", d.getId());
                            diagRules.add(m);
                        }
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Diagnostics load failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void trySubmitWithDiagnose() {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        final String subject = safeText(etSubject);
        final String description = safeText(etDescription);

        if (subject.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please enter subject and description", Toast.LENGTH_SHORT).show();
            return;
        }

        if (diagRules.isEmpty()) {
            loadDiagRules();
        }

        String hay = (subject + " " + description).toLowerCase(Locale.getDefault());
        MatchResult best = new MatchResult(null, 0, new ArrayList<>());

        for (Map<String, Object> r : diagRules) {
            List<String> keys = getStringList(r.get("keywords"));
            if (keys.isEmpty()) continue;

            double score = 0;
            List<String> hits = new ArrayList<>();
            for (String kw : keys) {
                String k = kw == null ? "" : kw.toLowerCase(Locale.getDefault()).trim();
                if (!k.isEmpty() && hay.contains(k)) {
                    score += 0.25;
                    hits.add(kw);
                }
            }
            if (score > 1) score = 1;
            if (score > best.score) best = new MatchResult(r, score, hits);
        }

        // no match -> normal ticket
        if (best.rule == null || best.score < 0.20) {
            createTicket(subject, description, null, false);
            return;
        }

        Map<String, Object> ad = new HashMap<>();
        ad.put("ruleId", str(best.rule.get("id")));
        ad.put("title", str(best.rule.get("title")));
        ad.put("category", str(best.rule.get("category")));
        ad.put("severity", str(best.rule.get("severity")));
        ad.put("steps", getStringList(best.rule.get("steps")));
        ad.put("confidence", best.score);
        ad.put("version", num(best.rule.get("version"), 1));
        ad.put("explanation", "Matched: " + TextUtils.join(", ", best.hits));
        ad.put("createdAt", FieldValue.serverTimestamp());

        final double threshold = dbl(best.rule.get("confidenceThreshold"), 0.55);
        final MatchResult result = best;

        String cat = str(best.rule.get("category"));
        if (cat != null) preselectCategory(cat);

        StringBuilder msg = new StringBuilder();
        msg.append(str(best.rule.get("title")) == null ? "Possible fix found" : str(best.rule.get("title")));
        msg.append("\n\nConfidence: ").append((int) Math.round(best.score * 100)).append("%");
        List<String> steps = getStringList(best.rule.get("steps"));
        if (!steps.isEmpty()) {
            msg.append("\n\nSteps:\n");
            for (int i = 0; i < steps.size(); i++) {
                msg.append(i + 1).append(". ").append(steps.get(i)).append("\n");
            }
        }

        new AlertDialog.Builder(this)
                .setTitle("Auto-Diagnose")
                .setMessage(msg.toString())
                .setPositiveButton("Issue resolved", (d, w) ->
                        // this is the path you complained about
                        createTicket(subject, description, ad, true))
                .setNegativeButton("Proceed to create ticket", (d, w) ->
                        createTicket(subject, description, ad, result.score >= threshold))
                .setNeutralButton("Cancel", null)
                .show();
    }

    private void preselectCategory(@NonNull String detected) {
        String want = detected.trim().toLowerCase(Locale.getDefault());
        for (int i = 0; i < spCategory.getCount(); i++) {
            Object o = spCategory.getItemAtPosition(i);
            if (o == null) continue;
            String s = o.toString().trim().toLowerCase(Locale.getDefault());
            if (s.equals(want)) {
                spCategory.setSelection(i);
                return;
            }
        }
    }

    private void createTicket(String subject, String description,
                              Map<String, Object> autoDiagnosis,
                              boolean resolved) {

        String uid = auth.getCurrentUser().getUid();
        String category = (spCategory.getSelectedItem() != null)
                ? spCategory.getSelectedItem().toString()
                : "General";

        Map<String, Object> data = new HashMap<>();
        data.put("userId", uid);
        data.put("category", category);
        data.put("subject", subject);
        data.put("description", description);
        data.put("urgent", false);
        data.put("status", resolved ? "Resolved" : "Open");
        data.put("assignedTo", null);
        data.put("photoUrl", "");
        data.put("createdAt", FieldValue.serverTimestamp());
        data.put("updatedAt", FieldValue.serverTimestamp());
        if (resolved) data.put("resolvedBy", "auto-diagnose");
        if (autoDiagnosis != null) data.put("autoDiagnosis", autoDiagnosis);

        db.collection("tickets").add(data)
                .addOnSuccessListener(ref -> {
                    if (pickedImage != null) {
                        uploadPhotoThenUpdate(ref, uid, pickedImage, resolved);
                    } else {
                        Toast.makeText(this,
                                resolved ? "Issue resolved." : "Ticket created.",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Create failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void uploadPhotoThenUpdate(@NonNull DocumentReference ref,
                                       String uid,
                                       @NonNull Uri photo,
                                       boolean resolved) {
        StorageReference dst = storage.getReference()
                .child("tickets/" + uid + "/" + ref.getId() + ".jpg");

        dst.putFile(photo)
                .continueWithTask(task -> {
                    if (!task.isSuccessful()) throw task.getException();
                    return dst.getDownloadUrl();
                })
                .addOnSuccessListener(downloadUri -> {
                    Map<String, Object> patch = new HashMap<>();
                    patch.put("photoUrl", downloadUri.toString());
                    patch.put("updatedAt", Timestamp.now());

                    ref.set(patch, SetOptions.merge())
                            .addOnSuccessListener(v -> {
                                Toast.makeText(this,
                                        resolved ? "Issue resolved." : "Ticket created.",
                                        Toast.LENGTH_SHORT).show();
                                finish();
                            })
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "Update photoUrl failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Upload failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private static String safeText(EditText et) {
        return et.getText() == null ? "" : et.getText().toString().trim();
    }
    private static String str(Object o) { return (o instanceof String) ? ((String) o) : null; }
    private static double dbl(Object o, double def) {
        if (o instanceof Number) return ((Number) o).doubleValue();
        try { return Double.parseDouble(String.valueOf(o)); } catch (Throwable ignore) {}
        return def;
    }
    private static int num(Object o, int def) {
        if (o instanceof Number) return ((Number) o).intValue();
        return def;
    }
    @SuppressWarnings("unchecked")
    private static List<String> getStringList(Object v) {
        List<String> out = new ArrayList<>();
        if (v instanceof List) {
            for (Object x : (List<?>) v) if (x instanceof String) out.add((String) x);
        }
        return out;
    }

    private static class MatchResult {
        final Map<String, Object> rule;
        final double score;
        final List<String> hits;
        MatchResult(Map<String, Object> r, double s, List<String> h) { rule = r; score = s; hits = h; }
    }
}
