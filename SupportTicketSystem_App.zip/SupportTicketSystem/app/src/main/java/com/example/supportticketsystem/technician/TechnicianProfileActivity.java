package com.example.supportticketsystem.technician;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.supportticketsystem.R;
import com.example.supportticketsystem.auth.LoginActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class TechnicianProfileActivity extends AppCompatActivity {

    // UI
    private TextView tvProfName, tvProfEmail, tvProfContact, tvProfCategory, tvProfSolved;
    private DrawerLayout drawerLayout;
    private NavigationView navView;
    private ImageView btnHomeTech;

    // Firebase
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_technician_profile);

        // bind views
        tvProfName     = findViewById(R.id.tvProfName);
        tvProfEmail    = findViewById(R.id.tvProfEmail);
        tvProfContact  = findViewById(R.id.tvProfContact);
        tvProfCategory = findViewById(R.id.tvProfCategory);
        tvProfSolved   = findViewById(R.id.tvProfSolved);

        drawerLayout = findViewById(R.id.drawerLayoutTech);
        navView      = findViewById(R.id.navViewTech);
        btnHomeTech  = findViewById(R.id.btnHomeTech);

        // firebase
        auth = FirebaseAuth.getInstance();
        db   = FirebaseFirestore.getInstance();

        // top home icon
        if (btnHomeTech != null) {
            btnHomeTech.setOnClickListener(v -> {
                Intent i = new Intent(this, TechnicianDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            });
        }

        setupDrawer();

        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "No logged in user.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String uid = auth.getCurrentUser().getUid();

        // read from "users" (your screenshot shows the doc is in users)
        db.collection("users").document(uid)
                .get()
                .addOnSuccessListener(this::fillFromUserDoc)
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to load profile: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void setupDrawer() {
        if (navView == null) return;

        navView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_about) {
                startActivity(new Intent(this, InfoActivity.class));
            } else if (id == R.id.nav_profile) {
                // already here
            } else if (id == R.id.nav_logout) {
                doLogout();
            }

            if (drawerLayout != null) {
                drawerLayout.closeDrawer(GravityCompat.START);
            }
            return true;
        });
    }

    private void fillFromUserDoc(DocumentSnapshot doc) {
        if (doc == null || !doc.exists()) {
            Toast.makeText(this, "Profile not found.", Toast.LENGTH_SHORT).show();
            return;
        }

        // name/email
        String name = doc.getString("name");
        if (name == null || name.trim().isEmpty()) {
            name = doc.getString("fullName");
        }
        String email = doc.getString("email");

        // CONTACT: your Firestore uses "contactNumber"
        String contact = doc.getString("contactNumber");
        if (isEmpty(contact)) {
            // fallback to old names in case some docs were created earlier
            contact = doc.getString("phone");
        }
        if (isEmpty(contact)) {
            contact = doc.getString("contact");
        }

        // CATEGORY
        String category = doc.getString("category");
        if (isEmpty(category)) {
            category = "General";
        }

        // ASSIGNMENTS SOLVED
        // your doc has "activeCount": 4
        Long activeCount = doc.getLong("activeCount");

        // set UI
        tvProfName.setText(nonEmpty(name, "-"));
        tvProfEmail.setText(nonEmpty(email, "-"));
        tvProfContact.setText(nonEmpty(contact, "-"));
        tvProfCategory.setText(category);
        tvProfSolved.setText(activeCount != null ? String.valueOf(activeCount) : "0");

        // drawer header
        updateDrawerHeader(nonEmpty(name, "Technician"));
    }

    private void updateDrawerHeader(String name) {
        if (navView == null) return;
        View header = navView.getHeaderView(0);
        if (header == null) return;

        TextView tvHeaderName = header.findViewById(R.id.tvTechName);
        TextView tvHeaderRole = header.findViewById(R.id.tvTechRole);

        if (tvHeaderName != null) {
            tvHeaderName.setText(name);
        }
        if (tvHeaderRole != null) {
            tvHeaderRole.setText("AURA Technician");
        }
    }

    private String nonEmpty(String val, String fallback) {
        return (val != null && !val.trim().isEmpty()) ? val : fallback;
    }

    private boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    private void doLogout() {
        auth.signOut();
        Intent i = new Intent(this, LoginActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
