package com.example.supportticketsystem.model;

import com.google.firebase.Timestamp;

public class Message {
    public String id;
    public String senderId;
    public String receiverId; // 🔔 Add this
    public String text;
    public Timestamp createdAt;

    public Message() {}

    public Message(String id, String senderId, String receiverId, String text, Timestamp createdAt) {
        this.id = id;
        this.senderId = senderId;
        this.receiverId = receiverId;
        this.text = text;
        this.createdAt = createdAt;
    }
}
