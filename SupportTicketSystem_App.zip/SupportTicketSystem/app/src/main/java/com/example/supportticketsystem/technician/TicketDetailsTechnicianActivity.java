package com.example.supportticketsystem.technician;

import android.content.Intent;  // added
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;   // added

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import com.bumptech.glide.Glide;
import com.example.supportticketsystem.R;
import com.example.supportticketsystem.model.Ticket;
import com.example.supportticketsystem.model.TicketStore;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Source;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

public class TicketDetailsTechnicianActivity extends AppCompatActivity {

    public static final String EXTRA_TICKET_ID = "extra_ticket_id";

    private String ticketId;
    private FirebaseFirestore db;
    private FirebaseAuth auth;

    private TextView tvSubject, tvMeta, tvDescription, tvNoImages;
    private EditText etTechnicianNote;
    private Spinner spStatus;
    private Button btnUpdate;
    private GridLayout gridImages;

    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
    private ListenerRegistration reg;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket_details_technician);

        ticketId = getIntent().getStringExtra(EXTRA_TICKET_ID);
        if (TextUtils.isEmpty(ticketId)) {
            Toast.makeText(this, "Missing ticket ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        bindViews();

        // home button click
        ImageView btnHome = findViewById(R.id.btnHomeTech);
        if (btnHome != null) {
            btnHome.setOnClickListener(v -> {
                Intent i = new Intent(this, TechnicianDashboardActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(i);
                finish();
            });
        }

        // grab a fresh copy (no local cache), then keep it live
        fetchOnceFromServer();
        attachRealtime();

        btnUpdate.setOnClickListener(v -> doUpdate());
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (reg != null) { reg.remove(); reg = null; }
    }

    private void bindViews() {
        tvSubject       = findViewById(R.id.tvSubject);
        tvMeta          = findViewById(R.id.tvMeta);
        tvDescription   = findViewById(R.id.tvDescription);
        etTechnicianNote= findViewById(R.id.etTechnicianNote);
        spStatus        = findViewById(R.id.spStatus);
        btnUpdate       = findViewById(R.id.btnUpdateStatus);
        gridImages      = findViewById(R.id.gridImages);
        tvNoImages      = findViewById(R.id.tvNoImages);
    }

    private void fetchOnceFromServer() {
        db.collection("tickets").document(ticketId)
                .get(Source.SERVER)
                .addOnSuccessListener(this::bindDoc)
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Load failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void attachRealtime() {
        reg = db.collection("tickets").document(ticketId)
                .addSnapshotListener((d, e) -> {
                    if (e != null || d == null || !d.exists()) return;
                    bindDoc(d);
                });
    }

    @SuppressWarnings("unchecked")
    private void bindDoc(DocumentSnapshot d) {
        if (!d.exists()) {
            Toast.makeText(this, "Ticket not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Ticket t = TicketStore.fromDoc(d);

        // Subject + code
        String code = t.code != null ? t.code : (t.id == null ? "" : t.id);
        String subjectLine = (t.subject != null && !t.subject.isEmpty() ? t.subject : "(No subject)");
        if (!TextUtils.isEmpty(code)) subjectLine += "  •  " + code;
        tvSubject.setText(subjectLine);

        // Category + createdAt
        String cat = (t.category == null || t.category.isEmpty()) ? "General" : t.category;
        String date = (t.createdAt == null) ? "" : sdf.format(((Timestamp) t.createdAt).toDate());
        tvMeta.setText(cat + (date.isEmpty() ? "" : " • " + date));

        // Description (+ optional auto-diagnostic block)
        String desc = t.description == null ? "" : t.description;

        // Prefer the field present on the doc; fall back to model map if needed
        Map<String, Object> diag = null;
        Object ad = d.get("autoDiagnostic"); // ✅ your current schema
        if (ad instanceof Map) {
            diag = (Map<String, Object>) ad;
        } else if (t.autoDiagnostic != null && !t.autoDiagnostic.isEmpty()) {
            diag = t.autoDiagnostic;
        }
        String autoBlock = buildAutoDiagnosticBlock(diag);
        tvDescription.setText(TextUtils.isEmpty(autoBlock) ? desc : autoBlock + "\n\n" + desc);

        // Prefill tech note
        String techNote = d.getString("technicianNote");
        if (techNote != null) etTechnicianNote.setText(techNote);

        // Prefill status (array from strings.xml)
        String status = d.getString("status");
        if (status != null) {
            String[] arr = getResources().getStringArray(R.array.ticket_status_array);
            for (int i = 0; i < arr.length; i++) {
                if (arr[i].equalsIgnoreCase(status)) {
                    spStatus.setSelection(i);
                    break;
                }
            }
        }

        // 🔥 Photos from multiple possible fields (robust)
        showImages(extractImageUrls(d));
    }

    /** Build the Auto-Diagnostic text block (optional). */
    private String buildAutoDiagnosticBlock(Map<String, Object> ad) {
        if (ad == null || ad.isEmpty()) return "";
        String title = safeStr(ad.get("title"));
        String aCat  = safeStr(ad.get("category"));
        String sev   = safeStr(ad.get("severity"));
        double conf  = 0;
        Object c = ad.get("confidence");
        if (c instanceof Number) conf = ((Number) c).doubleValue();

        StringBuilder sb = new StringBuilder();
        sb.append("[Auto-Diagnose]\n");
        if (!TextUtils.isEmpty(title)) sb.append(title).append("\n");
        if (!TextUtils.isEmpty(aCat) || !TextUtils.isEmpty(sev)) {
            sb.append("Category: ").append(TextUtils.isEmpty(aCat) ? "-" : aCat);
            sb.append("   •   Severity: ").append(TextUtils.isEmpty(sev) ? "-" : sev).append("\n");
        }
        if (conf > 0) sb.append("Confidence: ").append(Math.round(conf * 100)).append("%\n");

        List<String> steps = listStr(ad.get("steps"));
        if (steps != null && !steps.isEmpty()) {
            sb.append("Steps:\n");
            for (int i = 0; i < steps.size(); i++) {
                sb.append("  ").append(i + 1).append(". ").append(steps.get(i)).append("\n");
            }
        }
        return sb.toString().trim();
    }

    /** Collects image URLs from all likely places. */
    private List<String> extractImageUrls(DocumentSnapshot d) {
        List<String> out = new ArrayList<>();

        // Common array fields
        addFromList(out, d.get("photoUrls"));
        addFromList(out, d.get("imageUrls"));
        addFromList(out, d.get("photos"));
        addFromList(out, d.get("images"));

        // Attachments can be strings (url) or maps with { url: ... }
        addFromAttachments(out, d.get("attachments"));

        // Single string fields (various spellings)
        addIfString(out, d.get("photoUrl"));   // ✅ your NewTicketActivity sets this
        addIfString(out, d.get("photoURL"));
        addIfString(out, d.get("imageUrl"));
        addIfString(out, d.get("imageURL"));
        addIfString(out, d.get("image"));
        addIfString(out, d.get("photo"));

        // Ensure uniqueness & non-empty
        List<String> unique = new ArrayList<>();
        for (String url : out) {
            if (!TextUtils.isEmpty(url) && !unique.contains(url)) unique.add(url);
        }
        return unique;
    }

    @SuppressWarnings("unchecked")
    private void addFromList(List<String> out, Object listField) {
        if (listField instanceof List) {
            for (Object o : (List<?>) listField) {
                if (o instanceof String && !TextUtils.isEmpty((String) o)) {
                    out.add((String) o);
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    private void addFromAttachments(List<String> out, Object attachments) {
        if (!(attachments instanceof List)) return;
        for (Object o : (List<?>) attachments) {
            if (o instanceof String && !TextUtils.isEmpty((String) o)) {
                out.add((String) o);
            } else if (o instanceof Map) {
                Object url = ((Map<?, ?>) o).get("url");
                if (url instanceof String && !TextUtils.isEmpty((String) url)) {
                    out.add((String) url);
                }
            }
        }
    }

    private void addIfString(List<String> out, Object field) {
        if (field instanceof String && !TextUtils.isEmpty((String) field)) out.add((String) field);
    }

    private void showImages(List<String> urls) {
        gridImages.removeAllViews();

        if (urls == null || urls.isEmpty()) {
            tvNoImages.setVisibility(View.VISIBLE);
            return;
        }

        tvNoImages.setVisibility(View.GONE);
        gridImages.setColumnCount(3);

        for (String url : urls) {
            AppCompatImageView img = new AppCompatImageView(this);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            img.setLayoutParams(lp);
            img.setAdjustViewBounds(true);
            img.setScaleType(AppCompatImageView.ScaleType.CENTER_CROP);

            Glide.with(this)
                    .load(url)
                    .placeholder(android.R.drawable.ic_menu_report_image)
                    .error(android.R.drawable.stat_notify_error)
                    .into(img);

            gridImages.addView(img);
        }
    }

    private void doUpdate() {
        String note = etTechnicianNote.getText() == null ? "" : etTechnicianNote.getText().toString().trim();
        String status = spStatus.getSelectedItem() == null ? "Resolved" : spStatus.getSelectedItem().toString();

        Map<String, Object> update = new HashMap<>();
        update.put("technicianNote", note);
        update.put("status", status);
        update.put("updatedAt", FieldValue.serverTimestamp());
        if (auth.getCurrentUser() != null) update.put("updatedBy", auth.getCurrentUser().getUid());

        btnUpdate.setEnabled(false);

        db.collection("tickets").document(ticketId)
                .update(update)
                .addOnSuccessListener(v -> {
                    Toast.makeText(this, "Ticket updated successfully", Toast.LENGTH_SHORT).show();
                    btnUpdate.setEnabled(true);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    btnUpdate.setEnabled(true);
                });
    }

    /* helpers */
    private static String safeStr(Object o) { return (o instanceof String) ? (String) o : null; }

    @SuppressWarnings("unchecked")
    private static List<String> listStr(Object v) {
        List<String> out = new ArrayList<>();
        if (v instanceof List)
            for (Object x : (List<?>) v)
                if (x instanceof String) out.add((String) x);
        return out;
    }
}
