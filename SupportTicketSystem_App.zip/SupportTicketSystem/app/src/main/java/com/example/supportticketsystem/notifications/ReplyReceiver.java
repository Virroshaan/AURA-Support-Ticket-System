package com.example.supportticketsystem.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.core.app.RemoteInput;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

/**
 * Handles inline replies from notifications.
 * Supports:
 *  - ticketChat  -> tickets/{ticketId}/messages
 *  - directChat  -> directChats/{roomId}/messages
 *
 * Extras expected on the PendingIntent:
 *   "type"           : "ticketChat" | "directChat"
 *   "ticketId"       : ticket id (for ticketChat)
 *   "roomId"         : direct chat room id (for directChat)
 *   "adminUid"       : optional (not required to send)
 *   KEY_INLINE (RemoteInput): the text reply
 */
public class ReplyReceiver extends BroadcastReceiver {

    public static final String KEY_INLINE = "inline_reply";
    private static final String TAG = "ReplyReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            CharSequence cs = getMessageText(intent);
            if (cs == null) return;
            String text = cs.toString().trim();
            if (text.isEmpty()) return;

            FirebaseAuth auth = FirebaseAuth.getInstance();
            if (auth.getCurrentUser() == null) {
                Log.w(TAG, "No logged-in user; ignoring inline reply");
                return;
            }
            String uid = auth.getCurrentUser().getUid();
            FirebaseFirestore db = FirebaseFirestore.getInstance();

            String type = intent.getStringExtra("type");
            if ("directChat".equals(type)) {
                // --- Direct chat inline reply ---
                String roomId = intent.getStringExtra("roomId");
                if (roomId == null || roomId.isEmpty()) {
                    Log.w(TAG, "Missing roomId for directChat inline reply");
                    return;
                }

                Map<String, Object> m = new HashMap<>();
                m.put("senderId", uid);
                m.put("text", text);
                m.put("createdAt", FieldValue.serverTimestamp());

                // Touch room meta so list can sort immediately
                db.collection("directChats").document(roomId)
                        .set(new HashMap<String, Object>() {{
                            put("updatedAt", FieldValue.serverTimestamp());
                        }}, com.google.firebase.firestore.SetOptions.merge());

                db.collection("directChats").document(roomId)
                        .collection("messages")
                        .add(m)
                        .addOnFailureListener(e ->
                                Log.e(TAG, "Failed to send direct inline reply", e));

            } else {
                // --- Ticket chat inline reply ---
                String ticketId = intent.getStringExtra("ticketId");
                if (ticketId == null || ticketId.isEmpty()) {
                    Log.w(TAG, "Missing ticketId for ticketChat inline reply");
                    return;
                }

                // Read ticket to compute receiverId (opposite side)
                db.collection("tickets").document(ticketId).get()
                        .addOnSuccessListener(snap -> {
                            if (!snap.exists()) {
                                Log.w(TAG, "Ticket not found for inline reply: " + ticketId);
                                return;
                            }
                            String userId = snap.getString("userId");
                            String techId = snap.getString("assignedTo");

                            String receiverId = null;
                            if (uid != null) {
                                if (uid.equals(userId)) receiverId = techId;
                                else if (uid.equals(techId)) receiverId = userId;
                            }
                            // If still null, allow write without receiverId (CF can still deliver)
                            Map<String, Object> m = new HashMap<>();
                            m.put("senderId", uid);
                            if (receiverId != null) m.put("receiverId", receiverId);
                            m.put("text", text);
                            m.put("createdAt", FieldValue.serverTimestamp());

                            // Touch ticket meta so lists update immediately (CF will handle unread increment)
                            Map<String, Object> touch = new HashMap<>();
                            touch.put("lastMessageAt", FieldValue.serverTimestamp());
                            touch.put("lastMessageText", text);
                            touch.put("lastMessageSenderId", uid);
                            touch.put("updatedAt", FieldValue.serverTimestamp());
                            db.collection("tickets").document(ticketId)
                                    .set(touch, com.google.firebase.firestore.SetOptions.merge());

                            db.collection("tickets").document(ticketId)
                                    .collection("messages")
                                    .add(m)
                                    .addOnFailureListener(e ->
                                            Log.e(TAG, "Failed to send ticket inline reply", e));
                        })
                        .addOnFailureListener(e ->
                                Log.e(TAG, "Failed reading ticket before inline reply", e));
            }

        } catch (Throwable t) {
            Log.e(TAG, "Inline reply failed", t);
        }
    }

    private CharSequence getMessageText(Intent intent) {
        BundleCompat b = new BundleCompat(intent);
        return b.getRemoteInputText(KEY_INLINE);
    }

    /** Small helper to safely read RemoteInput across API levels / libraries */
    private static class BundleCompat {
        private final Intent intent;
        BundleCompat(Intent intent) { this.intent = intent; }
        CharSequence getRemoteInputText(String key) {
            try {
                android.os.Bundle results = RemoteInput.getResultsFromIntent(intent);
                return results == null ? null : results.getCharSequence(key);
            } catch (Throwable ignore) {
                return null;
            }
        }
    }
}
